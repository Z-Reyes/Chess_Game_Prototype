﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PieceData
{
    // Start is called before the first frame update
    public enum pieceType { pawn, rook, knight, bishop, king, queen, empty};

    public pieceType mytype;
    public bool isAlive;
    public bool is_black;
    public bool is_first_move = true;
}
