﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Board_Master : MonoBehaviour
{
    // Start is called before the first frame update
    public Board_Meta_Data[,] myBoard = new Board_Meta_Data[8,8];
    public GameObject[] whitePieces = new GameObject[16];
    public GameObject[] blackPieces = new GameObject[16];
    public Vector3 rightUnit = new Vector3(-0.00375f,0.0f,0.0f);
    public Vector3 downUnit = new Vector3(0.0f, -0.00375f, 0.0f);

    public float speed = 1.0f;
    public bool inTransit = false;
    public Transform currPiece;
    public Vector3 modifier;

    void Start()
    {
        inTransit = true;

        //myBoard = new Board_Meta_Data[8, 8];
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                myBoard[i, j] = new Board_Meta_Data();
                myBoard[i, j].currObject = null;
                myBoard[i,j].piece_info.mytype = PieceData.pieceType.empty;
                
            }
        }
       // Debug.Log(myBoard.Length);
      //  foreach (Board_Meta_Data j in myBoard)
       // {
            //Debug.Log("Iteration");

       // }
        Debug.Log(myBoard.Length);
        FillBoard();
        inTransit = false;

    }
    //Simply fills the board with the appropriate data.
    void FillBoard()
    {
        myBoard[0,0].piece_info.mytype = PieceData.pieceType.rook;
        myBoard[0, 0].piece_info.is_black = false;
        myBoard[0, 0].piece_info.isAlive = true;
        myBoard[0, 0].currObject = whitePieces[0];
        MovePieceBoard(myBoard[0, 0].currObject.transform, 1, 1);


        myBoard[0, 1].piece_info.mytype = PieceData.pieceType.knight;
        myBoard[0, 1].piece_info.is_black = false;
        myBoard[0, 1].piece_info.isAlive = true;
        myBoard[0, 1].currObject = whitePieces[1];
        MovePieceBoard(myBoard[0, 1].currObject.transform, 1, 2);

        myBoard[0, 2].piece_info.mytype = PieceData.pieceType.bishop;
        myBoard[0, 2].piece_info.is_black = false;
        myBoard[0, 2].piece_info.isAlive = true;
        myBoard[0, 2].currObject = whitePieces[2];
        MovePieceBoard(myBoard[0, 2].currObject.transform, 1, 3);

        myBoard[0, 3].piece_info.mytype = PieceData.pieceType.king;
        myBoard[0, 3].piece_info.is_black = false;
        myBoard[0, 3].piece_info.isAlive = true;
        myBoard[0, 3].currObject = whitePieces[3];
        MovePieceBoard(myBoard[0, 3].currObject.transform, 1, 4);

        myBoard[0, 4].piece_info.mytype = PieceData.pieceType.queen;
        myBoard[0, 4].piece_info.is_black = false;
        myBoard[0, 4].piece_info.isAlive = true;
        myBoard[0, 4].currObject = whitePieces[4];
        MovePieceBoard(myBoard[0, 4].currObject.transform, 1, 5);

        myBoard[0, 7].piece_info.mytype = PieceData.pieceType.rook;
        myBoard[0, 7].piece_info.is_black = false;
        myBoard[0, 7].piece_info.isAlive = true;
        myBoard[0, 7].currObject = whitePieces[7];
        MovePieceBoard(myBoard[0, 7].currObject.transform, 1, 8);

        myBoard[0, 6].piece_info.mytype = PieceData.pieceType.knight;
        myBoard[0, 6].piece_info.is_black = false;
        myBoard[0, 6].piece_info.isAlive = true;
        myBoard[0, 6].currObject = whitePieces[6];
        MovePieceBoard(myBoard[0, 6].currObject.transform, 1, 7);

        myBoard[0, 5].piece_info.mytype = PieceData.pieceType.bishop;
        myBoard[0, 5].piece_info.is_black = false;
        myBoard[0, 5].piece_info.isAlive = true;
        myBoard[0, 5].currObject = whitePieces[5];
        MovePieceBoard(myBoard[0, 5].currObject.transform, 1, 6);

        for (int i = 0; i < 8; i++)
        {
            myBoard[1, i].piece_info.mytype = PieceData.pieceType.pawn;
            myBoard[1, i].piece_info.is_black = false;
            myBoard[1, i].piece_info.isAlive = true;
            myBoard[1, i].currObject = whitePieces[8 + i];
            MovePieceBoard(myBoard[1, i].currObject.transform, 2, i + 1);

        }




        myBoard[7, 0].piece_info.mytype = PieceData.pieceType.rook;
        myBoard[7, 0].piece_info.is_black = true;
        myBoard[7, 0].piece_info.isAlive = true;
        myBoard[7, 0].currObject = blackPieces[0];
        MovePieceBoard(myBoard[7, 0].currObject.transform, 8, 1);

        myBoard[7, 1].piece_info.mytype = PieceData.pieceType.knight;
        myBoard[7, 1].piece_info.is_black = true;
        myBoard[7, 1].piece_info.isAlive = true;
        myBoard[7, 1].currObject = blackPieces[1];
        MovePieceBoard(myBoard[7, 1].currObject.transform, 8, 2);

        myBoard[7, 2].piece_info.mytype = PieceData.pieceType.bishop;
        myBoard[7, 2].piece_info.is_black = true;
        myBoard[7, 2].piece_info.isAlive = true;
        myBoard[7, 2].currObject = blackPieces[2];
        MovePieceBoard(myBoard[7, 2].currObject.transform, 8, 3);

        myBoard[7, 3].piece_info.mytype = PieceData.pieceType.king;
        myBoard[7, 3].piece_info.is_black = true;
        myBoard[7, 3].piece_info.isAlive = true;
        myBoard[7, 3].currObject = blackPieces[3];
        MovePieceBoard(myBoard[7, 3].currObject.transform, 8, 4);

        myBoard[7, 4].piece_info.mytype = PieceData.pieceType.queen;
        myBoard[7, 4].piece_info.is_black = true;
        myBoard[7, 4].piece_info.isAlive = true;
        myBoard[7, 4].currObject = blackPieces[4];
        MovePieceBoard(myBoard[7, 4].currObject.transform, 8, 5);

        myBoard[7, 7].piece_info.mytype = PieceData.pieceType.rook;
        myBoard[7, 7].piece_info.is_black = true;
        myBoard[7, 7].piece_info.isAlive = true;
        myBoard[7, 7].currObject = blackPieces[7];
        MovePieceBoard(myBoard[7, 7].currObject.transform, 8, 8);

        myBoard[7, 6].piece_info.mytype = PieceData.pieceType.knight;
        myBoard[7, 6].piece_info.is_black = true;
        myBoard[7, 6].piece_info.isAlive = true;
        myBoard[7, 6].currObject = blackPieces[6];
        MovePieceBoard(myBoard[7, 6].currObject.transform, 8, 7);

        myBoard[7, 5].piece_info.mytype = PieceData.pieceType.bishop;
        myBoard[7, 5].piece_info.is_black = true;
        myBoard[7, 5].piece_info.isAlive = true;
        myBoard[7, 5].currObject = blackPieces[5];
        MovePieceBoard(myBoard[7, 5].currObject.transform, 8, 6);

        for (int i = 0; i < 8; i++)
        {
            myBoard[6, i].piece_info.mytype = PieceData.pieceType.pawn;
            myBoard[6, i].piece_info.is_black = true;
            myBoard[6, i].piece_info.isAlive = true;
            myBoard[6, i].currObject = blackPieces[8 + i];
            MovePieceBoard(myBoard[6, i].currObject.transform, 7, i + 1);
        }
    }

    public void MovePiece(int source_row, int source_col, int destination_row, int destination_column)
    {
        //Check that piece actually exists.
        Board_Meta_Data currentPiece = myBoard[source_row-1, source_col-1];
        Board_Meta_Data potential_dest_piece = myBoard[destination_row - 1, destination_column - 1];
        if (currentPiece.piece_info.mytype != PieceData.pieceType.empty)
        {


            if (CheckValidPiece(currentPiece, potential_dest_piece, source_row, source_col, destination_row, destination_column))
            {
                //Now we move the piece.
                //First, move the piece to the new location.
                MovePieceBoard(currentPiece.currObject.transform, destination_row, destination_column);
                CopyData(currentPiece, ref myBoard[destination_row - 1, destination_column - 1]);
                // myBoard[destination_row - 1, destination_column - 1].currObject = currentPiece.currObject;
                // myBoard[destination_row - 1, destination_column - 1].piece_info.mytype = currentPiece.piece_info.mytype;
                // myBoard[destination_row - 1, destination_column - 1].piece_info.is_black = currentPiece.piece_info.is_black;
                // myBoard[destination_row - 1, destination_column - 1].piece_info.isAlive = currentPiece.piece_info.isAlive;

                //Now we need to transport the piece.

                ClearPiece(source_row - 1, source_col - 1);

            }else
            {
                Debug.Log("Cannot move piece there!");
            }
        } else
        {
            if (currentPiece.piece_info.mytype == PieceData.pieceType.empty)
            {
                Debug.Log("spot is empty!");
            }
        }
    }

    //Returns true if the space being moved to is valid.
    //Valid in this case corresponds to if the piece type allows it to move there, and if the piece at the destination (if any)
    //is of the opposite color. Otherwise, return false.
    bool CheckValidPiece(Board_Meta_Data source_space, Board_Meta_Data dest_space, int sr, int sc, int dr, int dc)
    {
        bool is_valid_space = false;
        bool is_same_type = false;
        switch (source_space.piece_info.mytype)
        {
                //legal move for rook
            case PieceData.pieceType.rook:
                if (dr == sr || dc == sc && !(dr == sr && dc == sc))
                {
                    is_valid_space = true;
                }
                else
                {
                    is_valid_space = false;
                }
                break;

            case PieceData.pieceType.bishop:
                //legal move for bishop
                if (sr != dr && sc != dc && Math.Abs(dr - sr) == Math.Abs(dc - sc))
                {
                    is_valid_space = true;
                }
                else
                {
                    is_valid_space = false;
                }
                break;
                
            case PieceData.pieceType.king:
                //legal move for king
                if (Math.Abs(dc - sc) <= 1 &&  Math.Abs(dr - sr) <= 1 && !(dr == sr && dc == sc))
                {
                    is_valid_space = true;
                }
                else
                {
                    is_valid_space = false;
                }
                break;

            case PieceData.pieceType.queen:
                //legal move for queen
                if (sr != dr && sc != dc && Math.Abs(dr - sr) == Math.Abs(dc - sc) || (sr == dr || sc == dc))
                {
                    is_valid_space = true;
                }
                else
                {
                    is_valid_space = false;
                }
                break;

            case PieceData.pieceType.pawn:
                //legal move for pawn
                if (dc == sc || (Math.Abs(dc - sc) == 1 && dest_space.piece_info.is_black != source_space.piece_info.is_black && dest_space.piece_info.mytype != PieceData.pieceType.empty))
                {
                    if (!source_space.piece_info.is_black)
                    {
                        if (dr - sr == 1 || (dr - sr == 2 && source_space.piece_info.is_first_move && dc == sc))
                        {
                            is_valid_space = true;
                        } else
                        {
                            is_valid_space = false;
                        }

                    }
                    else
                    {
                        if (dr - sr == -1 || (dr - sr == -2 && source_space.piece_info.is_first_move && dc == sc))
                        {
                            is_valid_space = true;
                        } else
                        {
                            is_valid_space = false;
                        }

                    }
                } else
                {
                    is_valid_space = false;
                }


                break;

            case PieceData.pieceType.knight:
                //test for legal knight move:
                int columnAbDiff = Math.Abs(dr - sr);
                int rowAbDiff = Math.Abs(dc - sc);
                if (rowAbDiff <= 2 && columnAbDiff <= 2 && rowAbDiff + columnAbDiff == 3)
                {
                    is_valid_space = true;
                } else
                {
                    is_valid_space = false;
                }
                break;

            default:
                //PieceData.pieceType.empty;
                break;
        }

        if (dest_space.currObject != null)
        {
            if (dest_space.piece_info.is_black == source_space.piece_info.is_black)
            {
                is_same_type = true;
            }
            else
            {
                is_same_type = false;
            }
        }

        return (is_valid_space && !is_same_type);
    }

        
  

        void CopyData(Board_Meta_Data source, ref Board_Meta_Data dest)
        {
        source.piece_info.is_first_move = false;
            dest.piece_info.mytype = source.piece_info.mytype;
            dest.piece_info.isAlive = source.piece_info.isAlive;
            dest.piece_info.is_black = source.piece_info.is_black;
        dest.piece_info.is_first_move = source.piece_info.is_first_move;

        dest.currObject = source.currObject;
        }
        void ClearPiece(int row, int column)
        {
            myBoard[row, column].currObject = null;
            myBoard[row, column].piece_info.isAlive = false;
            myBoard[row, column].piece_info.mytype = PieceData.pieceType.empty;

        }

        void MovePieceBoard(Transform piece, int dest_row, int dest_col)
        {
        Debug.Log("Moving Board Piece!");
        piece.localPosition = new Vector3(0.02625f, 0.02625f, piece.localPosition.z);
        //Vector3 targetPosition = new Vector3(0.02625f, 0.02625f, piece.localPosition.z);
        modifier = ((rightUnit * 2) * (dest_col - 1)) + ((downUnit * 2) * (dest_row - 1));
        piece.localPosition += modifier;
    }


        void Update()
        {
        // Debug.Log("Moving Board Piece!");
        // MovePieceBoard(myBoard[0, 0].currObject.transform, 1, 1);

      //  float step = speed * Time.deltaTime;
      //  if (inTransit)
      //      currPiece.localPosition = Vector3.MoveTowards(currPiece.localPosition, modifier, step);
      //  if (Vector3.Distance(currPiece.localPosition, modifier) < 0.001f)
       //     inTransit = false;

        // Debug.Log("Moving Board Piece!");
        // MovePieceBoard(myBoard[0, 0].currObject.transform, 1, 1);
    }


}
