﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Board_Meta_Data
{
    public PieceData piece_info = new PieceData();
    public GameObject currObject;
}
