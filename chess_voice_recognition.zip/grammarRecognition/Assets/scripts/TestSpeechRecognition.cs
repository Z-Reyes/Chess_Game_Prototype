﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Windows.Speech;
//using UnityEngine.UI;
public class TestSpeechRecognition : MonoBehaviour
{
    public string[] keywords = new string[] { "rotate left", "rotate right" };
    public ConfidenceLevel confidence = ConfidenceLevel.Medium;
  //  GrammarRecognizer grammar;
   // grammar = new GrammarRecognizer("assest");
    public float speed = 1;

    protected PhraseRecognizer recognizer;
    protected string word = "rotate right";
    // Start is called before the first frame update
    void Start()
    {
        if (keywords != null)
        {
            recognizer = new KeywordRecognizer(keywords, confidence);
            recognizer.OnPhraseRecognized += Recognizer_OnPhraseRecognized;
            recognizer.Start();
        }
    }
    private void Recognizer_OnPhraseRecognized(PhraseRecognizedEventArgs args)
    {
        word = args.text;
       // results.text = "You said: <b>" + word + "</b>";
    }
    // Update is called once per frame
    void Update()
    {
        Debug.Log(word);
    }
    private void OnApplicationQuit()
    {
        if (recognizer != null && recognizer.IsRunning)
        {
            recognizer.OnPhraseRecognized -= Recognizer_OnPhraseRecognized;
            recognizer.Stop();
        }
    }
}
