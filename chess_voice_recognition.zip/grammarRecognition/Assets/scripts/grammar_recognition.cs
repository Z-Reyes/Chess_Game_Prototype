﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Windows.Speech;
using UnityEngine.UI;
//using System.Linq;
public class grammar_recognition : MonoBehaviour
{

    //  private GrammarRecognizer grammarRecognizer;
    private GrammarRecognizer grammarRecognizer;
    public Board_Master master;
    public ConfidenceLevel confidence = ConfidenceLevel.Medium;
    public string message = "";
    public Transform boardTransform;
    int inTransition = 0;
    int MaxRotation = 90;
    bool istransitioning = false;
    private string pathData;
    public Text feedback_text;
    public Text confirmation_text;
    bool command_recognized = false;
    int command_confirmed = 0;
    string[] commandArgs;
    // Start is called before the first frame update
    void Start()
    {
        command_recognized = false;
        command_confirmed = 0;
        pathData = Application.dataPath;
        Debug.Log(pathData);
        grammarRecognizer = new GrammarRecognizer(pathData + "/chess_grammar.xml", confidence);
        Debug.Log(pathData + "/chess_grammar.xml");
        grammarRecognizer.OnPhraseRecognized += OnGrammarRecognized;
        grammarRecognizer.Start();
    }

    // Update is called once per frame
    void Update()
    {
       //First, check whether a command was recognized:
       if (command_recognized)
        {
            //Then, if the command was confirmed, parse the instruction.
            if (command_confirmed == 2)
            {
                ParseInstruction(commandArgs);
                command_recognized = false;
                command_confirmed = 0;
                feedback_text.text = "";
                confirmation_text.text = "Listening to\nCommands...";
                
            } else if (command_confirmed == 1)
            {
                command_recognized = false;
                command_confirmed = 0;
                feedback_text.text = "";
                confirmation_text.text = "Listening to\nCommands...";
            }
        }

        if (istransitioning && inTransition != MaxRotation)
        {
            if (MaxRotation > inTransition)
            {
                inTransition += 5;
                boardTransform.Rotate(new Vector3(0, 0, 5), Space.Self);
            }
            else if (MaxRotation < inTransition)
            {
                inTransition -= 5;
                boardTransform.Rotate(new Vector3(0, 0, -5), Space.Self);
            }

            if (MaxRotation == inTransition)
            {
                istransitioning = false;
            }
        }

    }
    void OnGrammarRecognized(PhraseRecognizedEventArgs args)
    {
       // SemanticMeaning[] meanings = args.semanticMeanings;
        // do something 
        Debug.Log("I recognized that!");
        message = args.text;
        Debug.Log(message);
        //taken from https://docs.microsoft.com/en-us/dotnet/csharp/how-to/parse-strings-using-split
        
        if (!command_recognized)
        {
            command_recognized = true;
            commandArgs = message.Split(' ');
            feedback_text.text = "Did you say: " + message + "?";
            confirmation_text.text = "Command Recognized:\nSay Yes/No based on command accuracy.";
        } else
        {
            string[] tempYesNo = message.Split(' ');
            ParseInstruction(tempYesNo);
        }
        //ParseInstruction(commandArgs);

    }

    void ParseInstruction(string [] instruction)
    {
        string first = instruction[0];

        if (command_recognized && command_confirmed == 2) {
            switch (first)
            {
                case "rotate":
                    bool direction = false;
                    MaxRotation = -90;
                    if (instruction[1] == "right")
                    {
                        MaxRotation = 90;
                        direction = true;
                    }
                    //RotateBoard(direction);
                    inTransition = 0;
                    istransitioning = true;
                    break;
                case "move":
                    MovePieceTranslation(instruction);
                    break;
                case "show":
                    //Insert code
                    break;

                default:
                    break;
            }
        }

        if (command_recognized)
        {
            switch(first)
            {
                case "yes":
                    command_confirmed = 2;
                    break;
                case "no":
                    command_confirmed = 1;
                    break;
                default:
                    break;
            }
        }
    }

    //Translates the string information into raw 
    void MovePieceTranslation(string[] moveData)
    {
        string piecetype = moveData[1];
        int[] translatedLocations = new int[4];
        string[] rawLocations = new string[4];
        rawLocations[0] = moveData[3];
        rawLocations[1] = moveData[4];
        rawLocations[2] = moveData[6];
        rawLocations[3] = moveData[7];

        for (int i = 0; i < rawLocations.Length; i++)
        {
            switch(rawLocations[i])
            {
                case "K":
                case "one":
                    translatedLocations[i] = 1;
                    break;

                case "J":
                case "two":
                    translatedLocations[i] = 2;
                    break;

                case "I":
                case "three":
                    translatedLocations[i] = 3;
                    break;

                case "H":
                case "four":
                    translatedLocations[i] = 4;
                    break;

                case "F":
                case "five":
                    translatedLocations[i] = 5;
                    break;

                case "C":
                case "six":
                    translatedLocations[i] = 6;
                    break;

                case "B":
                case "seven":
                    translatedLocations[i] = 7;
                    break;

                case "A":
                case "eight":
                default:
                    translatedLocations[i] = 8;
                    break;
            }
        }

        //Now we send the instruction to the board.
        master.MovePiece(translatedLocations[0], translatedLocations[1], translatedLocations[2], translatedLocations[3]);
        Debug.Log(translatedLocations[0]);
        Debug.Log(translatedLocations[1]);
        Debug.Log(translatedLocations[2]);
        Debug.Log(translatedLocations[3]);


    }

    void RotateBoard(bool direction)
    {
        if (direction)
        {
            boardTransform.Rotate(new Vector3(0, 0, 90), Space.Self);
        }
        else
        {
            boardTransform.Rotate(new Vector3(0, 0, -90), Space.Self);
        }
    }

}
